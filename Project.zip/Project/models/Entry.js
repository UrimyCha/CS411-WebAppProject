const mongoose = require('mongoose')

const EntrySchema = new mongoose.Schema({
    minRent: {
        type: String,
        required: true
    },
    maxRent: {
        type: String,
        required: true
    },
    bedroom: {
        type: String,
        required: true
    },
    washroom: {
        type: String,
        required: true
    },
    state: {
        type: String,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    county: {
        type: String,
        required: true
    },
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
})

module.exports = mongoose.model('Entry', EntrySchema)