export default [
        {
            id: 1,
            title: "10 best place to live in US",
            coverImg: "18805524786_d8e8aaa84c_k.jpg",           
        },
        {
            id: 2,
            title: "33 Best Fall Vacations in the US",
            coverImg: "countryside-england-britain-fields-road-grass-wind-1080P-wallpaper.jpg",
        },
    ]