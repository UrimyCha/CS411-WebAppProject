import React from "react"

export default function Header() {
    return (
        <header className="header">
            <img 
                src="./images/troll-face.png" 
                className="header--image"
            />
            <h2 className="header--title">Search before move</h2>
            <h4 className="header--project">Log in</h4>
        </header>
    )
}