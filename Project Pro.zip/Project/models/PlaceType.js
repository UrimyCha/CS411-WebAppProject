const PlaceType = ['airport', 'aquarium', 'art_gallery', 'atm', 'bakery', 'bank', 'bar', 'beauty_salon', 'bicycle_store',
'book_store', 'bowling_alley', 'bus_station', 'cafe', 'campground', 'car_dealer', 'car_rental',
'car_repair', 'car_wash', 'casino', 'cemetery', 'church', 'clothing_store', 'convenience_store', 'dentist',
'department_store', 'drugstore', 'eletrician', 'electronics_store', 'embassy', 'fire_station', 'florist', 'furniture_store',
'gas_station', 'gym', 'hair care', 'hardware_store', 'home goods store', 'hospital', 'insurance_agency', 'jewelry_store',
'library', 'light_rail_station', 'liquor_store', 'locksmith', 'movie_rental', 'movie_theater', 'museum', 'night_club',
'park', 'parking', 'pet_store', 'pharmacy', 'plumber', 'police', 'post_office', 'primary_school', 'real_estate_agency',
'restaurant', 'secondary_school', 'shoe_store', 'shopping_mall', 'spa', 'stadium', 'storage', 'subway_station', 'supermarket',
'taxi_stand', 'tourist_attraction', 'train_station', 'university'];

module.exports = PlaceType;