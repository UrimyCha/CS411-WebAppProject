const express = require('express')
const router = express.Router()
const { ensureAuth, ensureGuest } = require('../middleware/auth')
const place_type = require('../models/PlaceType')

const Entry = require('../models/Entry')
const Nearby = require('../models/NearbySearch')

//@desc Login/Landing page
//@route GET /
router.get('/', ensureGuest, (req, res) => {
    res.render('login', {
        layout: 'login',
    })
})

//@desc Dashboard
//@route GET /dashboard
router.get('/dashboard', ensureAuth, async (req, res) => {
    try {
        const entries = await Entry.find({ user: req.user.id }).lean()
        res.render('dashboard', {
            name: req.user.firstName,
            entries,
        })
    } catch (err) {
        console.error(err)
        res.render('error/500')
    }

})

//@desc     Nearby
//@route    GET /dashboard/nearby
router.get('/dashboard/nearby', ensureAuth, async (req, res) => {
    try {
        const nearby = await Nearby.find({ user: req.user.id }).lean()
        res.render('nearby', {
            name: req.user.firstName,
            nearby,
            placetype: place_type
        })
    } catch (err) {
        console.error(err)
        res.render('error/500')
    }
})

module.exports = router